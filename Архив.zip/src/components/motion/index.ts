export { AnimatePresence } from 'framer-motion';
export { FadeIn } from './FadeIn';
export { SlideUp } from './SlideUp';
export * from './transitions';
