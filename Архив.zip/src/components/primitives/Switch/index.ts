export { Switch, type SwitchProps } from './Switch';
